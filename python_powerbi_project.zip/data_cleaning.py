
import pandas as pd

# Load the dataset
df = pd.read_csv("superstore_sales.csv")

# Convert order date to datetime
df['Order Date'] = pd.to_datetime(df['Order Date'])

# Drop unnecessary columns (none in this generated dataset)
# df = df.drop(columns=['Row ID', 'Postal Code'])

# Handle missing values
df = df.dropna()

# Add a new column: Profit Margin
df['Profit Margin'] = df['Profit'] / df['Sales']

# Save cleaned data
df.to_csv("cleaned_sales_data.csv", index=False)

print("Data cleaning complete. Cleaned data saved to 'cleaned_sales_data.csv'")
